import React from 'react'
import { Link } from 'react-router-dom'

export default function MainFlight() {
  return (
    <div className="container">
    <h1 >
         <a href="/flight/findall">Findall</a>
         
    </h1>
    </div>
  )
}
